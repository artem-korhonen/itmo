import os

# Указываем начальную директорию
start_directory = 'java'

# Создаем/открываем файл для записи
with open('output.txt', 'w', encoding='utf-8') as output_file:
    # Проходим по всем нижним директориям
    for root, dirs, files in os.walk(start_directory):
        # Ограничение, чтобы не идти выше по уровню
        # Проверка, чтобы идти только по дочерним папкам
        if root.count(os.sep) == start_directory.count(os.sep):
            continue
        # Перебираем файлы
        for file in files:
            if file.endswith('.java'):
                file_path = os.path.join(root, file)
                # Читаем содержимое файла и добавляем в output.txt
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    output_file.write(f'--- {file_path} ---\n')
                    output_file.write(content + '\n\n')
